import React, { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  Factory,
  Gauge,
  ShieldCheck,
  Wrench,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const API = "http://127.0.0.1:8000/api/v1";

function Status({ value }) {
  return <span className={`status ${value}`}>{value}</span>;
}

function App() {
  const [machines, setMachines] = useState([]);
  const [overview, setOverview] = useState({});
  const [alerts, setAlerts] = useState([]);
  const [selected, setSelected] = useState(null);
  const [history, setHistory] = useState([]);
  const [explanation, setExplanation] = useState("");
  const [activeView, setActiveView] = useState("control");
  const [sensorIntel, setSensorIntel] = useState(null);
  const [riskMonitor, setRiskMonitor] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);

  async function load() {
    const [m, o, a] = await Promise.all([
      fetch(`${API}/machines`).then(r => r.json()),
      fetch(`${API}/analytics/overview`).then(r => r.json()),
      fetch(`${API}/alerts?active_only=true`).then(r => r.json()),
    ]);
    setMachines(m);
    setOverview(o);
    setAlerts(a);

    if (selected) {
      const fresh = m.find(x => x.id === selected.id);
      if (fresh) setSelected(fresh);
    } else if (m.length) {
      setSelected(m[0]);
    }
  }

  async function loadMachine(machine) {
    setSelected(machine);
    const data = await fetch(`${API}/sensors/${machine.id}?hours=6`).then(r => r.json());

    const grouped = {};
    for (const row of data) {
      const key = new Date(row.timestamp).toLocaleTimeString();
      grouped[key] ||= { time: key };
      grouped[key][row.sensor_type] = row.value;
    }

    setHistory(Object.values(grouped).slice(-80));

    const e = await fetch(`${API}/analytics/machines/${machine.id}/explain`).then(r => r.json());
    setExplanation(e.explanation);
  }

  async function openSensorIntelligence() {
    setActiveView("sensors");
    setActionLoading(true);
    try {
      const data = await fetch(`${API}/analytics/sensor-intelligence`).then(r => {
        if (!r.ok) throw new Error("Sensor intelligence request failed");
        return r.json();
      });
      setSensorIntel(data);
    } catch (err) {
      setSensorIntel({ error: err.message });
    } finally {
      setActionLoading(false);
    }
  }

  async function openRiskMonitor() {
    setActiveView("risk");
    setActionLoading(true);
    try {
      const data = await fetch(`${API}/analytics/maintenance-risk`).then(r => {
        if (!r.ok) throw new Error("Maintenance risk request failed");
        return r.json();
      });
      setRiskMonitor(data);
    } catch (err) {
      setRiskMonitor({ error: err.message });
    } finally {
      setActionLoading(false);
    }
  }

  function openControlCenter() {
    setActiveView("control");
  }

  async function resolveAlert(id) {
    await fetch(`${API}/alerts/${id}/resolve`, { method: "POST" });
    await load();
  }

  useEffect(() => {
    load();
    const timer = setInterval(load, 3000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (selected) loadMachine(selected);
  }, [selected?.id]);

  const critical = useMemo(
    () => machines.filter(m => m.status === "critical").length,
    [machines]
  );

  return (
    <div className="app">
      <aside>
        <div className="brand"><Factory /> <span>TwinForge</span></div>
        <div className="subtitle">Industrial Digital Twin</div>

        <nav>
          <button className={activeView === "control" ? "active" : ""} onClick={openControlCenter}><Gauge /> Control Center</button>
          <button className={activeView === "sensors" ? "active" : ""} onClick={openSensorIntelligence}><Activity /> Sensor Intelligence</button>
          <button className={activeView === "maintenance" ? "active" : ""} onClick={() => setActiveView("maintenance")}><Wrench /> Maintenance</button>
          <button className={activeView === "risk" ? "active" : ""} onClick={openRiskMonitor}><ShieldCheck /> Risk Monitor</button>
        </nav>

        <div className="system">
          <div className="dot" />
          Simulation Online
        </div>
      </aside>

      <main>
        <header>
          <div>
            <h1>Factory Control Center</h1>
            <p>Real-time digital twin, health monitoring and predictive maintenance.</p>
          </div>
          <div className="live"><span /> LIVE</div>
        </header>

        <section className="cards">
          <div className="card"><span>Machines</span><strong>{overview.machines || 0}</strong></div>
          <div className="card"><span>Healthy</span><strong>{overview.healthy || 0}</strong></div>
          <div className="card"><span>Warning</span><strong>{overview.warning || 0}</strong></div>
          <div className="card danger"><span>Critical</span><strong>{critical}</strong></div>
          <div className="card"><span>Avg Health</span><strong>{overview.average_health || 0}%</strong></div>
        </section>

        <section className="grid">
          <div className="panel machines">
            <div className="panel-title">
              <h2>Virtual Factory</h2>
              <span>{machines.length} assets</span>
            </div>

            {machines.map(machine => (
              <button
                key={machine.id}
                className={`machine ${selected?.id === machine.id ? "selected" : ""}`}
                onClick={() => loadMachine(machine)}
              >
                <div className="machine-icon"><Factory /></div>
                <div className="machine-info">
                  <strong>{machine.name}</strong>
                  <small>{machine.machine_type} · {machine.location}</small>
                </div>
                <div className="machine-score">
                  <b>{machine.health_score.toFixed(1)}%</b>
                  <Status value={machine.status} />
                </div>
              </button>
            ))}
          </div>

          <div className="panel">
            <div className="panel-title">
              <div>
                <h2>{selected?.name || "Select a machine"}</h2>
                <span>Digital twin telemetry</span>
              </div>
              {selected && <Status value={selected.status} />}
            </div>

            {selected && (
              <>
                <div className="metrics">
                  <Metric label="Health" value={`${selected.health_score.toFixed(1)}%`} />
                  <Metric label="Risk" value={`${selected.risk_score.toFixed(1)}%`} />
                  <Metric label="State" value={selected.status} />
                </div>

                <div className="chart">
                  <ResponsiveContainer width="100%" height={280}>
                    <LineChart data={history}>
                      <XAxis dataKey="time" hide />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="temperature" dot={false} />
                      <Line type="monotone" dataKey="vibration" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="explanation">
                  <div className="panel-title">
                    <h3>AI / Risk Explanation</h3>
                    <AlertTriangle size={18} />
                  </div>
                  <p>{explanation || "Waiting for telemetry..."}</p>
                </div>
              </>
            )}
          </div>
        </section>

        <section className="panel">
          <div className="panel-title">
            <h2>Active Maintenance Alerts</h2>
            <span>{alerts.length} active</span>
          </div>

          {alerts.length === 0 ? (
            <div className="empty">No active alerts.</div>
          ) : (
            alerts.slice(0, 8).map(alert => (
              <div className="alert" key={alert.id}>
                <AlertTriangle />
                <div>
                  <strong>{alert.title}</strong>
                  <p>{alert.message}</p>
                </div>
                <Status value={alert.severity === "high" ? "critical" : "warning"} />
              </div>
            ))
          )}
        </section>

        {activeView === "sensors" && (
          <section className="panel feature-view">
            <div className="panel-title">
              <div><h2>Sensor Intelligence</h2><span>Live telemetry interpretation and anomaly signals</span></div>
              <span>{actionLoading ? "Analyzing…" : `${sensorIntel?.total_anomaly_events || 0} anomaly events`}</span>
            </div>
            {sensorIntel?.error ? <div className="empty">{sensorIntel.error}</div> : (sensorIntel?.machines || []).map(item => (
              <div className="intel-row" key={item.machine_id}>
                <div><strong>{item.machine}</strong><small>{item.status} · health {item.health_score}%</small></div>
                <div className="intel-values">
                  {Object.entries(item.latest || {}).map(([key, val]) => <span key={key}><b>{key}</b> {Number(val.value).toFixed(2)} {val.unit}</span>)}
                </div>
                <div><Status value={item.status} /> <small>{item.anomaly_events} anomalies</small></div>
              </div>
            ))}
          </section>
        )}

        {activeView === "maintenance" && (
          <section className="panel feature-view">
            <div className="panel-title"><div><h2>Maintenance Center</h2><span>Active work queue and alert resolution</span></div><span>{alerts.length} active</span></div>
            {alerts.length === 0 ? <div className="empty">No active maintenance alerts.</div> : alerts.map(alert => (
              <div className="alert" key={alert.id}>
                <AlertTriangle />
                <div><strong>{alert.title}</strong><p>{alert.message}</p></div>
                <button className="resolve" onClick={() => resolveAlert(alert.id)}>Resolve</button>
              </div>
            ))}
          </section>
        )}

        {activeView === "risk" && (
          <section className="panel feature-view">
            <div className="panel-title">
              <div><h2>Maintenance Risk Monitor</h2><span>Prioritized machine risk and recommended actions</span></div>
              <span>{actionLoading ? "Refreshing…" : "LIVE"}</span>
            </div>
            {riskMonitor?.error ? <div className="empty">{riskMonitor.error}</div> : (riskMonitor?.items || []).map(item => (
              <div className="risk-row" key={item.machine_id}>
                <div><strong>{item.machine}</strong><small>{item.machine_type} · {item.location}</small></div>
                <div><strong>{item.risk_score}% risk</strong><small>{item.health_score}% health</small></div>
                <Status value={item.status} />
                <div className="risk-action"><b>{item.priority}</b><small>{item.recommended_action}</small></div>
              </div>
            ))}
          </section>
        )}
      </main>
    </div>
  );
}

function Metric({ label, value }) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

export default App;
