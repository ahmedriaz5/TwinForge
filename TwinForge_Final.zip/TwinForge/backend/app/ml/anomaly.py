from pathlib import Path
import joblib
import numpy as np
from sklearn.ensemble import IsolationForest

FEATURES = ["temperature", "vibration", "pressure", "rpm", "current"]

class AnomalyModel:
    def __init__(self, model_path: str = "ml/models/anomaly_model.joblib"):
        self.model_path = Path(model_path)
        self.model = None

    def train(self, rows: list[dict]):
        X = np.array([[float(row[f]) for f in FEATURES] for row in rows])
        self.model = IsolationForest(
            n_estimators=150,
            contamination=0.08,
            random_state=42,
        )
        self.model.fit(X)
        self.model_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self.model, self.model_path)

    def load(self):
        if self.model_path.exists():
            self.model = joblib.load(self.model_path)
        return self.model is not None

    def predict(self, values: dict[str, float]) -> tuple[bool, float]:
        if self.model is None and not self.load():
            return False, 0.0

        X = np.array([[float(values[f]) for f in FEATURES]])
        prediction = int(self.model.predict(X)[0])
        raw = float(self.model.decision_function(X)[0])

        # Convert to a simple 0..1 anomaly score.
        score = max(0.0, min(1.0, 0.5 - raw))
        return prediction == -1, round(score, 4)

anomaly_model = AnomalyModel()
