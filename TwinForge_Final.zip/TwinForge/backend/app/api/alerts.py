from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.alert import Alert
from app.schemas.alert import AlertOut

router = APIRouter(prefix="/alerts", tags=["Alerts"])

@router.get("", response_model=list[AlertOut])
def list_alerts(
    active_only: bool = False,
    db: Session = Depends(get_db),
):
    query = db.query(Alert)
    if active_only:
        query = query.filter(Alert.resolved.is_(False))
    return query.order_by(Alert.created_at.desc()).limit(200).all()

@router.post("/{alert_id}/resolve")
def resolve_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.get(Alert, alert_id)
    if not alert:
        return {"error": "Alert not found"}
    alert.resolved = True
    db.commit()
    return {"status": "resolved", "alert_id": alert_id}
