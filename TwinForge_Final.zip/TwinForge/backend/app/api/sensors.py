from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.machine import Machine
from app.models.sensor import SensorReading
from app.schemas.sensor import SensorCreate, SensorOut
from app.services.ingestion import ingest_reading

router = APIRouter(prefix="/sensors", tags=["Sensors"])

@router.post("", response_model=SensorOut)
def create_sensor_reading(payload: SensorCreate, db: Session = Depends(get_db)):
    machine = db.get(Machine, payload.machine_id)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    return ingest_reading(
        db, machine, payload.sensor_type, payload.value, payload.unit, payload.timestamp
    )

@router.get("/{machine_id}", response_model=list[SensorOut])
def machine_history(
    machine_id: int,
    hours: int = Query(24, ge=1, le=720),
    db: Session = Depends(get_db),
):
    if not db.get(Machine, machine_id):
        raise HTTPException(status_code=404, detail="Machine not found")

    since = datetime.utcnow() - timedelta(hours=hours)
    return (
        db.query(SensorReading)
        .filter(
            SensorReading.machine_id == machine_id,
            SensorReading.timestamp >= since,
        )
        .order_by(SensorReading.timestamp.asc())
        .all()
    )
