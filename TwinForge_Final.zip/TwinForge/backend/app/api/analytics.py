from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.machine import Machine
from app.models.sensor import SensorReading
from app.models.alert import Alert
from app.services.explanation import explain_with_llm

router = APIRouter(prefix="/analytics", tags=["Analytics"])

@router.get("/overview")
def overview(db: Session = Depends(get_db)):
    machines = db.query(Machine).all()
    alerts = db.query(Alert).filter(Alert.resolved.is_(False)).count()

    return {
        "machines": len(machines),
        "healthy": sum(m.status == "healthy" for m in machines),
        "warning": sum(m.status == "warning" for m in machines),
        "critical": sum(m.status == "critical" for m in machines),
        "active_alerts": alerts,
        "average_health": round(
            sum(m.health_score for m in machines) / len(machines), 2
        ) if machines else 0,
    }


@router.get("/sensor-intelligence")
def sensor_intelligence(db: Session = Depends(get_db)):
    """Return a live sensor intelligence snapshot for the dashboard."""
    machines = db.query(Machine).order_by(Machine.id).all()
    result = []
    limits = {
        "temperature": 80.0,
        "vibration": 5.0,
        "pressure": 11.0,
        "current": 18.0,
    }
    for machine in machines:
        rows = (
            db.query(SensorReading)
            .filter(SensorReading.machine_id == machine.id)
            .order_by(SensorReading.timestamp.desc())
            .limit(100)
            .all()
        )
        latest = {}
        anomaly_count = 0
        for row in rows:
            latest.setdefault(row.sensor_type, {
                "value": row.value,
                "unit": row.unit,
                "timestamp": row.timestamp,
            })
            if row.is_anomaly:
                anomaly_count += 1
        flags = []
        for sensor_type, limit in limits.items():
            item = latest.get(sensor_type)
            if item and item["value"] > limit:
                flags.append({"sensor": sensor_type, "value": item["value"], "limit": limit})
        result.append({
            "machine_id": machine.id,
            "machine": machine.name,
            "status": machine.status,
            "health_score": round(machine.health_score, 1),
            "risk_score": round(machine.risk_score, 1),
            "latest": latest,
            "anomaly_events": anomaly_count,
            "flags": flags,
        })
    return {"machines": result, "total_anomaly_events": sum(x["anomaly_events"] for x in result)}


@router.get("/maintenance-risk")
def maintenance_risk(db: Session = Depends(get_db)):
    """Return prioritized maintenance risk information and actions."""
    machines = db.query(Machine).order_by(Machine.risk_score.desc()).all()
    items = []
    for machine in machines:
        if machine.status == "critical":
            action = "Immediate inspection / controlled shutdown"
            priority = "critical"
        elif machine.status == "warning":
            action = "Schedule inspection and monitor telemetry"
            priority = "high"
        else:
            action = "Continue monitoring"
            priority = "routine"
        items.append({
            "machine_id": machine.id,
            "machine": machine.name,
            "machine_type": machine.machine_type,
            "location": machine.location,
            "status": machine.status,
            "health_score": round(machine.health_score, 1),
            "risk_score": round(machine.risk_score, 1),
            "priority": priority,
            "recommended_action": action,
            "last_seen": machine.last_seen,
        })
    return {
        "items": items,
        "critical": sum(x["status"] == "critical" for x in items),
        "warning": sum(x["status"] == "warning" for x in items),
        "routine": sum(x["status"] == "healthy" for x in items),
    }

@router.get("/machines/{machine_id}/explain")
def explain(machine_id: int, db: Session = Depends(get_db)):
    machine = db.get(Machine, machine_id)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")

    rows = (
        db.query(SensorReading)
        .filter(SensorReading.machine_id == machine_id)
        .order_by(SensorReading.timestamp.desc())
        .limit(100)
        .all()
    )

    readings = {}
    for row in rows:
        readings.setdefault(row.sensor_type, row.value)

    text = explain_with_llm(
        machine.name, readings, machine.risk_score, machine.status
    )

    return {
        "machine_id": machine.id,
        "risk_score": machine.risk_score,
        "status": machine.status,
        "explanation": text,
    }
