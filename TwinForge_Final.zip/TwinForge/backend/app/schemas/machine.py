from datetime import datetime
from pydantic import BaseModel, ConfigDict

class MachineOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    machine_type: str
    location: str
    health_score: float
    status: str
    risk_score: float
    last_seen: datetime | None
