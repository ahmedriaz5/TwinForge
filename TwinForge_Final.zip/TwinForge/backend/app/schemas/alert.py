from datetime import datetime
from pydantic import BaseModel, ConfigDict

class AlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    machine_id: int
    severity: str
    title: str
    message: str
    risk_score: float
    resolved: bool
    created_at: datetime
