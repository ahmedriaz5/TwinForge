from datetime import datetime
from pydantic import BaseModel, ConfigDict

class SensorCreate(BaseModel):
    machine_id: int
    sensor_type: str
    value: float
    unit: str
    timestamp: datetime | None = None

class SensorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    machine_id: int
    sensor_type: str
    value: float
    unit: str
    is_anomaly: bool
    anomaly_score: float
    timestamp: datetime
