def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))

def calculate_risk(readings: dict[str, float]) -> tuple[float, str, float]:
    """
    Demonstration risk engine for synthetic factory data.
    Returns risk score, status, health score.
    """
    risk = 0.0

    temp = readings.get("temperature", 0)
    vibration = readings.get("vibration", 0)
    pressure = readings.get("pressure", 0)
    current = readings.get("current", 0)

    if temp > 80:
        risk += min(30, (temp - 80) * 1.2)
    if vibration > 5:
        risk += min(35, (vibration - 5) * 8)
    if pressure < 4 or pressure > 11:
        risk += 15
    if current > 18:
        risk += min(20, (current - 18) * 2)

    risk = clamp(risk)
    health = clamp(100 - risk)

    if risk >= 70:
        status = "critical"
    elif risk >= 40:
        status = "warning"
    else:
        status = "healthy"

    return round(risk, 2), status, round(health, 2)

def recommendation(status: str, readings: dict[str, float]) -> str:
    if status == "critical":
        return "Schedule immediate inspection. Prioritize vibration, temperature and electrical-load checks."
    if status == "warning":
        return "Inspect the machine during the next maintenance window and monitor abnormal sensors closely."
    return "Continue normal operation and routine preventive maintenance."
