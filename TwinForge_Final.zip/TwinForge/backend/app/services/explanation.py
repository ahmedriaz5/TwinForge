from app.core.config import settings

def explain_with_llm(machine_name: str, readings: dict[str, float], risk: float, status: str) -> str:
    if not settings.LLM_ENABLED or not settings.OPENAI_API_KEY:
        return (
            f"{machine_name} is currently {status} with a calculated risk score of {risk:.1f}. "
            "The explanation engine is running in deterministic mode. "
            "Review temperature, vibration, pressure and current trends before maintenance decisions."
        )

    from openai import OpenAI
    client = OpenAI(api_key=settings.OPENAI_API_KEY)

    prompt = (
        "You are an industrial maintenance analyst. Explain this synthetic machine state "
        "concisely and safely. Do not claim certainty or recommend unsafe physical actions.\n\n"
        f"Machine: {machine_name}\nStatus: {status}\nRisk: {risk}\n"
        f"Readings: {readings}"
    )

    response = client.responses.create(
        model=settings.LLM_MODEL,
        input=prompt,
    )
    return response.output_text
