from datetime import datetime
from sqlalchemy.orm import Session
from app.models.machine import Machine
from app.models.sensor import SensorReading
from app.models.alert import Alert
from app.services.risk import calculate_risk, recommendation

SENSOR_LIMITS = {
    "temperature": (0, 120),
    "vibration": (0, 20),
    "pressure": (0, 20),
    "rpm": (0, 5000),
    "current": (0, 50),
}

def ingest_reading(
    db: Session,
    machine: Machine,
    sensor_type: str,
    value: float,
    unit: str,
    timestamp: datetime | None = None,
):
    low, high = SENSOR_LIMITS.get(sensor_type, (-float("inf"), float("inf")))
    anomaly = value < low or value > high

    # The ML service is intentionally separated. The rule is a safe baseline.
    reading = SensorReading(
        machine_id=machine.id,
        sensor_type=sensor_type,
        value=value,
        unit=unit,
        is_anomaly=anomaly,
        anomaly_score=1.0 if anomaly else 0.0,
        timestamp=timestamp or datetime.utcnow(),
    )
    db.add(reading)

    latest = {}
    rows = (
        db.query(SensorReading)
        .filter(SensorReading.machine_id == machine.id)
        .order_by(SensorReading.timestamp.desc())
        .limit(100)
        .all()
    )
    for row in rows:
        latest.setdefault(row.sensor_type, row.value)

    latest[sensor_type] = value
    risk, status, health = calculate_risk(latest)

    machine.risk_score = risk
    machine.health_score = health
    machine.status = status
    machine.last_seen = reading.timestamp

    if status in ("warning", "critical"):
        alert = Alert(
            machine_id=machine.id,
            severity="high" if status == "critical" else "medium",
            title=f"{machine.name} requires attention",
            message=recommendation(status, latest),
            risk_score=risk,
        )
        db.add(alert)

    db.commit()
    db.refresh(reading)
    return reading
