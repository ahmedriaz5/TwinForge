from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import Base, engine

from app.models.machine import Machine
from app.models.sensor import SensorReading
from app.models.alert import Alert

from app.api.machines import router as machines_router
from app.api.sensors import router as sensors_router
from app.api.alerts import router as alerts_router
from app.api.analytics import router as analytics_router
from app.api.health import router as health_router

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="TwinForge API",
    description="AI Industrial Digital Twin & Predictive Maintenance Platform",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router, prefix=settings.API_PREFIX)
app.include_router(machines_router, prefix=settings.API_PREFIX)
app.include_router(sensors_router, prefix=settings.API_PREFIX)
app.include_router(alerts_router, prefix=settings.API_PREFIX)
app.include_router(analytics_router, prefix=settings.API_PREFIX)

@app.get("/")
def root():
    return {
        "project": "TwinForge",
        "version": "1.0.0",
        "status": "running",
    }
