from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    APP_NAME: str = "TwinForge"
    DEBUG: bool = True
    DATABASE_URL: str = "sqlite:///./twinforge.db"
    API_PREFIX: str = "/api/v1"

    LLM_ENABLED: bool = False
    OPENAI_API_KEY: str = ""
    LLM_MODEL: str = "gpt-4o-mini"

    SIMULATION_INTERVAL: float = 1.0

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore"
    )

settings = Settings()
