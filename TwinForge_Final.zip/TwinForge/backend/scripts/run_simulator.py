import math
import random
import time
from datetime import datetime

from app.core.database import SessionLocal
from app.models.machine import Machine
from app.services.ingestion import ingest_reading

UNITS = {
    "temperature": "C",
    "vibration": "mm/s",
    "pressure": "bar",
    "rpm": "rpm",
    "current": "A",
}

def generate(machine_index: int, tick: int, degraded: bool):
    phase = tick / 15.0 + machine_index

    temperature = 65 + 5 * math.sin(phase) + random.gauss(0, 1.2)
    vibration = 2.5 + 0.5 * math.sin(phase * 1.4) + random.gauss(0, 0.15)
    pressure = 7 + 0.6 * math.sin(phase * 0.7) + random.gauss(0, 0.12)
    rpm = 1450 + 80 * math.sin(phase) + random.gauss(0, 12)
    current = 12 + 1.2 * math.sin(phase * 0.8) + random.gauss(0, 0.3)

    if degraded:
        temperature += 25
        vibration += 4
        current += 7
        pressure += 2

    return {
        "temperature": round(temperature, 2),
        "vibration": round(max(0, vibration), 2),
        "pressure": round(max(0, pressure), 2),
        "rpm": round(max(0, rpm), 2),
        "current": round(max(0, current), 2),
    }

def main():
    print("TwinForge simulator started. Press Ctrl+C to stop.")
    tick = 0

    while True:
        db = SessionLocal()
        try:
            machines = db.query(Machine).order_by(Machine.id).all()
            for i, machine in enumerate(machines):
                # Every ~90 seconds one machine enters a synthetic degradation event.
                degraded = ((tick // 30) + i) % 6 == 5
                values = generate(i, tick, degraded)

                for sensor_type, value in values.items():
                    ingest_reading(
                        db,
                        machine,
                        sensor_type,
                        value,
                        UNITS[sensor_type],
                        datetime.utcnow(),
                    )

                print(
                    f"{datetime.now().isoformat(timespec='seconds')} | "
                    f"{machine.name} | "
                    f"health={machine.health_score:.1f} "
                    f"risk={machine.risk_score:.1f} "
                    f"status={machine.status}"
                )
        finally:
            db.close()

        tick += 1
        time.sleep(1)

if __name__ == "__main__":
    main()
