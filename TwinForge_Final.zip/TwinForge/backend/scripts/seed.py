from app.core.database import Base, engine, SessionLocal
from app.models.machine import Machine

Base.metadata.create_all(bind=engine)

machines = [
    ("Compressor A", "Compressor", "Zone A"),
    ("CNC Machine B", "CNC", "Zone B"),
    ("Pump C", "Pump", "Zone C"),
    ("Industrial Fan D", "Fan", "Zone D"),
    ("Generator E", "Generator", "Zone E"),
]

db = SessionLocal()

try:
    if db.query(Machine).count() == 0:
        for name, machine_type, location in machines:
            db.add(
                Machine(
                    name=name,
                    machine_type=machine_type,
                    location=location,
                )
            )
        db.commit()
        print("Seeded factory machines.")
    else:
        print("Machines already exist.")
finally:
    db.close()
