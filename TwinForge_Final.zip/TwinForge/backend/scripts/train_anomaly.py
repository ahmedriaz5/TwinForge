import random
from app.ml.anomaly import anomaly_model

rows = []
for _ in range(2000):
    rows.append({
        "temperature": random.gauss(65, 4),
        "vibration": random.gauss(2.5, 0.35),
        "pressure": random.gauss(7, 0.5),
        "rpm": random.gauss(1450, 70),
        "current": random.gauss(12, 0.8),
    })

anomaly_model.train(rows)
print("Anomaly model trained and saved.")
