from app.services.risk import calculate_risk, recommendation

def test_healthy_machine():
    risk, status, health = calculate_risk({
        "temperature": 65,
        "vibration": 2,
        "pressure": 7,
        "rpm": 1450,
        "current": 12,
    })
    assert status == "healthy"
    assert risk < 40
    assert health > 60

def test_critical_machine():
    risk, status, health = calculate_risk({
        "temperature": 110,
        "vibration": 10,
        "pressure": 14,
        "rpm": 1450,
        "current": 30,
    })
    assert status == "critical"
    assert risk >= 70
    assert health <= 30

def test_recommendation():
    assert "inspection" in recommendation("warning", {}).lower()
